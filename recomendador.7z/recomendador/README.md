Instrucciones

1. Crear un archivo .env en directorio raiz que contenga
DB_SERVER='##########'
DB_DATABASE='########'
DB_USUARIO='#########'
DB_CONTRA='##########'